/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exam;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SAID123
 */
public class Student extends HttpServlet{
     String driver="com.mysql.jdbc.Driver";
    String url="jdbc:mysql://localhost:3306/aa";
    String user="root";
    String password="said";
    
    String sname;
    String sadd;
    String mobile;
    public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException{
        PrintWriter out=res.getWriter();
          String id=req.getParameter("idd");
          int sid=Integer.parseInt(id);
    
        try {
            Class.forName(driver);
        Connection con= DriverManager.getConnection(url, user, password);
        
            PreparedStatement pstm=con.prepareStatement("SELECT * FROM lo where sid=?");
            pstm.setInt(1, sid);
            
            ResultSet rs=pstm.executeQuery();
            
            while (rs.next()) {                
                sname=rs.getString(2);
                sadd=rs.getString(3);
                mobile=rs.getString(4);
            }
            
        } catch (Exception e) {
        }
         
        out.print("<!DOCTYPE html>\n" +
"<html>\n" +
"    <head>\n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <title>JSP Page</title>\n" +
"    </head>\n" +
"    <body>\n" +
"        <h1>Student id : "+sid+"</h1>\n" +
"        <h1>Student name : "+sname+"</h1>\n" +
"        <h1>Student address : "+sadd+"</h1>\n" +
"        <h1>Student phone : "+mobile+"</h1>\n" +
"    </body>\n" +
"</html>");
        
    }
    
}
